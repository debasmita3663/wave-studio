import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.RUNWAYML_API_SECRET;
const API_VERSION = process.env.RUNWAY_API_VERSION || '2024-11-06';
const taskOwners = new Map();
const origins = (process.env.FRONTEND_ORIGIN || 'http://localhost:3000,http://127.0.0.1:3000')
  .split(',').map(x => x.trim()).filter(Boolean);

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin(origin, callback) {
  // Allow server-to-server and local file testing requests with no Origin header.
  if (!origin || origins.includes(origin)) return callback(null, true);
  return callback(new Error('This website origin is not allowed by the backend CORS configuration.'));
} }));
app.use(express.json({ limit: '5mb' }));
app.use('/api/video/generate', rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: Number(process.env.GENERATION_LIMIT_PER_HOUR || 5),
  standardHeaders: 'draft-8', legacyHeaders: false,
  message: { error: 'Too many video generation requests from this IP. Try again later.' }
}));

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Wave Studio AI Video API' }));

// Public, no-login mode: visitors can use generation without creating an account.

function sendProviderError(res, response, body) {
  const detail = body?.error || body?.message || body?.detail || `AI provider returned HTTP ${response.status}`;
  // Do not echo secrets or full provider headers to the browser.
  res.status(response.status >= 400 && response.status < 500 ? response.status : 502)
    .json({ error: String(detail).slice(0, 500) });
}

app.post('/api/video/generate', async (req, res) => {
  if (!API_KEY) return res.status(503).json({ error: 'The server owner has not configured RUNWAYML_API_SECRET yet.' });
  const { prompt, mode, imageDataUrl, duration = 5, ratio = '1280:720' } = req.body || {};
  if (typeof prompt !== 'string' || prompt.trim().length < 3 || prompt.length > 1000) {
    return res.status(400).json({ error: 'Prompt must be between 3 and 1,000 characters.' });
  }
  if (!['text', 'image'].includes(mode)) return res.status(400).json({ error: 'Mode must be text or image.' });
  if (![5, 10].includes(Number(duration))) return res.status(400).json({ error: 'Duration must be 5 or 10 seconds.' });
  const allowedRatios = ['1280:720', '720:1280', '960:960'];
  if (!allowedRatios.includes(ratio)) return res.status(400).json({ error: 'Unsupported aspect ratio.' });

  const input = { model: 'gen4.5', promptText: prompt.trim(), duration: Number(duration) };
  if (mode === 'text') {
    if (!['1280:720', '720:1280'].includes(ratio)) return res.status(400).json({ error: 'Text-to-video supports landscape 16:9 or portrait 9:16.' });
    input.ratio = ratio;
  } else {
    if (!['1280:720', '720:1280', '960:960'].includes(ratio)) return res.status(400).json({ error: 'Unsupported image-to-video aspect ratio.' });
    input.ratio = ratio;
  }
  if (mode === 'image') {
    if (typeof imageDataUrl !== 'string') return res.status(400).json({ error: 'Upload a PNG, JPEG, or WebP image for image-to-video.' });
    const match = imageDataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
    if (!match) return res.status(400).json({ error: 'Image must be a valid PNG, JPEG, or WebP data URL.' });
    const encoded = match[2];
    if (encoded.length > 4_200_000) return res.status(413).json({ error: 'Image is too large. Use an image under approximately 3 MB.' });
    input.promptImage = imageDataUrl;
  }

  try {
    const endpoint = mode === 'text' ? 'text_to_video' : 'image_to_video';
    const response = await fetch(`https://api.dev.runwayml.com/v1/${endpoint}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': API_VERSION
      },
      body: JSON.stringify(input)
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) return sendProviderError(res, response, body);
    if (!body.id) return res.status(502).json({ error: 'AI provider did not return a task ID.' });
    taskOwners.set(body.id, true);
    return res.status(202).json({ id: body.id, status: body.status || 'PENDING' });
  } catch (error) {
    console.error('Video generation request failed:', error.message);
    return res.status(502).json({ error: 'Could not reach the AI video provider. Try again later.' });
  }
});

app.get('/api/video/status/:id', async (req, res) => {
  if (!API_KEY) return res.status(503).json({ error: 'The server owner has not configured RUNWAYML_API_SECRET yet.' });
  const id = String(req.params.id || '');
  // Runway task IDs are UUIDs; reject arbitrary path input.
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
    return res.status(400).json({ error: 'Invalid task ID.' });
  }
  if (!taskOwners.has(id)) return res.status(404).json({ error: 'This task is not available in this server session. Start a new generation if needed.' });
  try {
    const response = await fetch(`https://api.dev.runwayml.com/v1/tasks/${encodeURIComponent(id)}`, {
      headers: { Authorization: `Bearer ${API_KEY}`, 'X-Runway-Version': API_VERSION }
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) return sendProviderError(res, response, body);
    if (['SUCCEEDED', 'FAILED', 'CANCELED'].includes(body.status)) taskOwners.delete(id);
    return res.json({ id: body.id, status: body.status, output: body.output, failure: body.failure, error: body.error });
  } catch (error) {
    console.error('Video status request failed:', error.message);
    return res.status(502).json({ error: 'Could not check generation status. Try again.' });
  }
});

// This server can serve the site too, or the static frontend can remain on GitHub Pages.
app.use(express.static('public'));
app.use((err, _req, res, _next) => {
  if (err?.message?.includes('origin')) return res.status(403).json({ error: err.message });
  console.error('Unhandled server error:', err.message);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT, () => console.log(`Wave Studio AI backend listening on port ${PORT}`));

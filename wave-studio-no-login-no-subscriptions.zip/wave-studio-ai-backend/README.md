# Wave Studio — no-login, no-subscription edition

This package contains the Wave Studio website and a Node.js backend for text-to-video and image-to-video generation.

## What this edition changes
- Removes the website's account/login/signup/password-reset interface.
- Removes Supabase authentication from the video-generation request flow.
- Removes monthly, Premium, Pro, and payment/subscription flows from the user-facing website.
- Lets visitors use the generation endpoint without creating an account.
- Keeps a per-IP generation limit to reduce abuse. This is not a paid tier.

## Important cost and setup facts
Visitors are not charged by Wave Studio and no payment page is included. However, AI video generation in this package uses the Runway API. The site owner must configure a valid `RUNWAYML_API_SECRET` on the backend host, and the provider may charge the owner for generation. Hosting may also have costs. Do not promise unlimited, cost-free AI generation until you have selected and tested a provider/model and hosting arrangement that is genuinely free for your usage.

The package does **not** make the website live automatically. GitHub Pages can host the static website, but it cannot run this Node.js backend. Deploy the backend to a Node-capable host, then enter its public URL in the AI Video Generator panel or set `apiBase` in `public/config.js`.

## Backend deployment
1. Deploy this `wave-studio-ai-backend` folder to a Node.js hosting service that supports Node 20+.
2. Build command: `npm install`; start command: `npm start`.
3. Set backend environment variables in the hosting dashboard (never commit secrets):
   - `RUNWAYML_API_SECRET`: your provider secret, stored only on the server.
   - `FRONTEND_ORIGIN`: exact public website origin, e.g. your GitHub Pages origin.
   - `GENERATION_LIMIT_PER_HOUR`: optional request limit, default 5 per IP per hour.
   - `PORT`: supplied automatically by many hosts.
4. Deploy the static `public/index.html` and `public/config.js` to GitHub Pages, or serve them from the backend.
5. Open `/api/health` on the backend URL. A successful response confirms the backend is running, not that video generation is configured.
6. Test text-to-video and image-to-video. A real generation test requires a valid provider key and may incur provider charges to the site owner.

## Security notes
- Never put `RUNWAYML_API_SECRET` in `public/config.js`, HTML, or GitHub.
- Public unauthenticated generation can be abused. Keep rate limits enabled and monitor provider usage.
- The website UI and API do not charge visitors, but provider/hosting bills remain the owner's responsibility.
